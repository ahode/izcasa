<?php  
session_start();
include 'parts/config.php';
require_once 'block_io.php';

$apiKey = "d1ea-2dc7-e410-2901";
$version = 2; // API version
$pin = "dannykome1";
$block_io = new BlockIo($apiKey, $pin, $version);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<meta name="description" content="Services for Bitcoins"/>
<link rel="stylesheet" href="parts/app.css">
<title>Services for Bitcoins</title>

</head>
<body>


<div id="header">
<a href="index.php"><div id="logo"><img src="./uploads/logo.png" alt=" " height="75" width="75"></a></div>
	<div id="amenu">
        <ul class="menu">
<?php if (isset($_SESSION['user_id'])) { ?>
	<li><a href="logout.php" title="Logout">Logout</a></li>
	<li><a href="cart.php" title="Your shopping cart">Cart (0)</a></li>
	<li><a href="orders.php" title="Your orders">Orders (0)</a></li>
	<li><a href="messages.php" title="Contact support">Messages (1)</a></li>
	<li><a href="user.php" title="Account settings">Settings</a></li>
	<li><a href="info.php" title="Frequently Answered Questions">FAQs</a></li>
	<li><a href="wallet.php" title="Your Bitcoin wallet">Wallet (0.000 &#3647;)</a></li>
	<li><a href="shop.php" title="products">Products</a></li>
	<p align="right"><strong>Welcome! </strong><strong><?php echo $_SESSION['user_name']; ?></strong></p>
	<?php } else { ?>
	<li><a href="login.php" title="Login">Login</a></li>
	<li><a href="register.php" title="Register">Register</a></li>
	<li><a href="info.php" title="Frequently Answered Questions">FAQs</a></li>
	<li><a href="shop.php" title="Sell Bitcoins">Products</a></li>
	<?php } ?>
		</ul>
	<div class="clear"></div>
    </div>
	</div>

	<div id="main">