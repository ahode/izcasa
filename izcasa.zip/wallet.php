<?php  
include 'parts/header.php';
$currentPrice = $block_io->get_current_price(array('price_base' => 'USD'));
$getBalance = $block_io->get_address_balance(array('labels' => $_SESSION['user_name']));
$result = mysqli_query($conn, "SELECT * FROM users WHERE name = '" . $_SESSION['user_name']. "'");
while($product=mysqli_fetch_object($result)){

if (isset($_POST['sendbtc'])) {
	$btcadd = $_POST['btcadd'];
	$btcamt = $_POST['btcamt'];
	if($block_io->withdraw(array('amounts' => $btcamt, 'to_addresses' => $btcadd, 'pin' => '69696969'))){
		echo "Successfully sent".$btcamt." to ".$btcadd;
	}else{
		echo "Error Sending".$btcamt." to ".$btcadd;
	}
}

?>

<h3>Bitcoin Wallet</h3>
Your Bitcoin balance: <strong><?php echo $getBalance->data->available_balance; ?> Bitcoins</strong>  (= 0.00 EUR)<br>
<br>
Your Bitcoin address: 
<strong><?php echo $product->address;?></strong><br><br>
To load your wallet, send Bitcoins to the address above.<br><br>
<strong>Withdraw Bitcoins:</strong><br><br>
<form name="btc" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
Withdraw Bitcoins to this address or username: <br><input type="text" class="txt" name="btcadd" size="50"><br>
Amount in Bitcoins: <br><input type="text" class="txt" name="btcamt" size="12"><br>
<br><input type="submit" class="buttn" value="Send Bitcoins" name="sendbtc"></form><br>
Transaction fee: ~0.001 &#3647;<br><br>
Exchange rate today: 1 &#3647; = <?php echo $currentPrice->data->prices[0]->price; ?><span> USD</span><br><br>
<a href="history.php">Transaction List</a><br><br>
<?php
} 
?>
<?php
include 'parts/footer.php'
?>