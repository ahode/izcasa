<?php  
include 'parts/header.php';
?>

<h3>Shipping info</h3>

<br><br><br>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
Shipping Address <br><textarea name="shippingAddress" placeholder="Enter delivery info here..." cols="45px"></textarea><br><br>
<input type="submit" class="buttn" name="confirm" value="Confirm Order">
</form>
<br><br><br>


<?php
if (isset($_POST['confirm'])) {

	$shippingAddress = mysqli_real_escape_string($conn, $_POST['shippingAddress']);
	echo $shippingAddress;

	//$sql = "INSERT INTO orders(id, shippingAddress, total, orderTime, products_id, quantity, subTotal, users_id) 
	//		VALUES (NULL, '" . $shippingAddress . "',  '" . $s . "', now(), '" . $cart[$i]->id . "', 
	//			'" . $cart[$i]->quantity . "',  '" . $cart[$i]->price * $cart[$i]->quantity . "', 
	//			'" . $_SESSION['user_id'] . "')";
	//$result = mysqli_query($conn, $sql);
	//echo "Your orders was successful";
}
?>
<?php
include 'parts/footer.php'
?>