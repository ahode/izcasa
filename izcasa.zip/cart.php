<?php  
include 'parts/header.php';
include 'item.php';

if(isset($_GET['id'])){

	if (isset($_POST['addtocart'])) {
		$qty=$_POST['qty'];
		}
	$result= mysqli_query($conn, 'SELECT * FROM products where id ='.$_GET['id']);
	$product= mysqli_fetch_object($result);
	$item = new Item();
	$item->id = $product->id;
	$item->name = $product->name;
	$item->price = $product->price;
	$item->quantity = $qty;

	//check if product exist//
	$index=-1;
	$cart = unserialize(serialize($_SESSION['cart']));
	for ($i=0; $i < count($cart); $i++)
		if ($cart[$i]->id==$_GET['id']){
			$index=$i;
			break;
		}
			if ($index==-1) {//if product doesent exist add it to card
				$_SESSION['cart'][]=$item;
			}else{//if product already exist add to card stock also causes refresh add prob
				//$cart[$index]->quantity=$cart[$index]->quantity+$qty;
				//$_SESSION['cart']=$cart;
				$cart[$index]->quantity=$qty;
				$_SESSION['cart']=$cart;
				//echo "product already exist";
			}
	} 

if (isset($_GET['index'])) {
	$cart=unserialize(serialize($_SESSION['cart']));
	unset($cart[$_GET['index']]);
	$cart=array_values($cart);
	$_SESSION['cart']=$cart;
	}
?>

<h3>Your shopping cart</h3>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table class="table1">
<thead>
<tr>
<th><strong>Product</strong></th>
<th><strong>Price</strong></th>
<th><strong>Quantity</strong></th>
<th><strong>Total</strong></th>
</tr>
</thead>

<?php
$cart = unserialize(serialize($_SESSION['cart']));
$s=0;
$index=0;
for ($i=0; $i<count($cart); $i++) { 
	$s += $cart[$i]->price * $cart[$i]->quantity;
if (isset($_POST['confirm'])) {
	//$qty1=mysqli_real_escape_string($conn, $_POST['qty1']);
	//echo $qty1;
	$oname = mysqli_real_escape_string($conn, $_POST['oname']);
	$shippingAddress = mysqli_real_escape_string($conn, $_POST['shippingAddress']);
	$sql = "INSERT INTO orders(id, shippingAddress, total, orderTime, name, products_id, quantity, subTotal, users_id) 
			VALUES (NULL, '" . $shippingAddress . "',  '" . $s . "', now(), '" . $cart[$i]->id . "' , '" . $cart[$i]->id . "', '" . $cart[$i]->quantity . "',  
			'" . $cart[$i]->price * $cart[$i]->quantity . "', '" . $_SESSION['user_id'] . "')";
	$result = mysqli_query($conn, $sql);
	echo "Your orders was successful";
}
?>
<tbody>
<tr>
<td><?php echo $cart[$i]->name; ?></td>
<td><?php echo $cart[$i]->price; ?></td>
<td><?php echo $cart[$i]->quantity; ?></td>
<td><?php echo $cart[$i]->price * $cart[$i]->quantity; ?></td>
<td><a href="cart.php?index=<?php echo $index; ?>&action=delete" onclick="return confirm('Are you sure?')" class="r">Remove</a></td>
</tr>
</tbody>

<?php 
	$index++;
	} 
?>
<tr>
<td colspan="4" align="right">Order Total</td>
<td align="left"><?php echo $s; ?></td></tr>

</table>
<input type="submit" class="buttn" value="Refresh amount" name="updatecart"><strong> Total order : $ <?php echo $s; ?> ~ btc 0.000</strong> 
<br><br><hr><br><br>
<h3>Confirm your order</h3>
Order Identifier <br><input type="text" name="oname" size="40" required><br><br>
Shipping Address <br><textarea name="shippingAddress" required placeholder="Enter delivery info here..." cols="45px"></textarea><br><br>
<input type="submit" class="buttn" id="checkout" name="confirm" value="Confirm Order">
</form>
<br>
<br>
<br>

<?php
include 'parts/footer.php';
?>