<?php  
include 'parts/header.php';

 // define variables and set to empty values
         $title = $price = $description = $image = "";
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $title = test_input($_POST["title"]);
            $price = test_input($_POST["price"]);
            $description = test_input($_POST["description"]);
            $imageName = test_input($_FILES['file']['name']);
         }
         
         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }

if(isset($_POST['upload'])){
 
$target_path = "uploads/";

$target_path = $target_path . basename( $_FILES['file']['name']); 

if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {//chemod 777 uploads dir
    echo "The file ".  basename( $_FILES['file']['name']). 
    " has been uploaded";

$sql = "INSERT INTO products (id, name, price, description, imageName, uploadTime) VALUES (NULL, '$title', '$price', '$description', '$imageName', now())";
if(mysqli_query($conn, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

} else{
    echo "There was an error uploading the file, please try again!";
}

}


    
?>

<form name="addProduct" method="post" action="admin.php" enctype="multipart/form-data">
<h3>Add product</h3>
Title:<br><input type="text" class="txt" name="title" size="30"><br><br>
Price:<br><input type="text" class="txt" name="price" size="30"><br><br>
Description:<br><textarea class="pure-input-1-2" name="description" placeholder="Describe your ad" cols="35px"></textarea><br><br>
Photo: <input type="file" name="file" size="50" /><br><br>

<!--Please enter the captcha code:<br>
<img src="//s5q54hfww56ov2xc.onion.guide/captcha.php" height="30" width="60" alt="CAPTCHA code" style="padding-top:7px;padding-bottom:3px;"><br>
<input type="text" class="txt" autocomplete="off" name="captcha" size="20"><br><br>-->
<input type="submit" class="buttn" value="Add prudoct" name="upload"></form><br>

<?php
include 'parts/footer.php'
?>