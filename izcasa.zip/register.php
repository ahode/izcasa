<?php  
include 'parts/header.php';

if(isset($_SESSION['user_id'])) {
	header("Location: index.php");
}
$error = false;
if (isset($_POST['signup'])) {
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);	
	$newAddressInfo=$block_io->get_new_address(array('label' => $name));
	$walletAddress=$newAddressInfo->data->address;
	echo "your wallet address is : ".$walletAddress;

	if (!preg_match("/^[a-zA-Z]+$/",$name)) {
		$error = true;
		$uname_error = "Name must contain only alphabets";
	}
	if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$error = true;
		$email_error = "Please Enter Valid Email ID";
	}
	if(strlen($password) < 6) {
		$error = true;
		$password_error = "Password must be minimum of 6 characters";
	}
	if($password != $cpassword) {
		$error = true;
		$cpassword_error = "Password and Confirm Password doesn't match";
	}
	if (!$error) {
		if(mysqli_query($conn, "INSERT INTO users(name, email, password, address, signupTime) 
			VALUES('" . $name . "', '" . $email . "', '" . $password . "', '" . $walletAddress . "', now())")) {
			$success_message = "Successfully Registered! <a href='login.php'>Click here to Login</a>";
		} else {
			$error_message = "Error in registering...User Already Exist";
		}
	}
}
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
<h3>Registration</h3>
Username:<br><input type="text" name="name" size="30" required value="<?php if($error) echo $name; ?>"><br><br>
Email:<br><input type="text" name="email" size="30" required value="<?php if($error) echo $name; ?>"><br><br>
Password:<br><input type="password" name="password" size="30"><br>
Repeat password:<br><input type="password" name="cpassword" size="30"><br><br>
<!--Please enter the captcha code:<br>
<input type="text" class="txt" autocomplete="off" name="captcha" size="20"><br><br>-->
<input type="submit" class="buttn" value="Register" name="signup"></form><br>
<span class="text-success"><?php if (isset($success_message)) { echo $success_message; } ?></span>
<br>
<?php  
include 'parts/footer.php';
?>