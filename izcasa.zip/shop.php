<?php  
include 'parts/header.php';
?>
<h3>Our catalog</h3>Featured Products!<br>
<br><br><br>

<table class="table1">
<thead>
<tr>
<th>Picture</th><th>Product</th><th>Price</th><th>Description</th><th>Quantity</th>
</tr>
</thead>
<tbody>

<?php
$result = mysqli_query($conn, "SELECT * FROM products") or die(mysql_error());  
while($product=mysqli_fetch_object($result)){
?>

<tr>
<td><img src="uploads/<?php echo $product->imageName;?>" alt=" " height="75" width="75"></td>
<td><?php echo $product->name;?></td>
<td><?php echo $product->price;?><span> USD</span></td>
<td><?php echo $product->description;?></td>
<td>
<form name="cart" method="post" action="cart.php?id=<?php echo $product->id ?>">
<input value="109" type="hidden" name="id">
<input value="add" type="hidden" name="action">
<input value="1" type="text" class="txt" name="qty" size="2"> X <input type="submit" class="buttn" value="Buy now" name="addtocart">
</form>
</td>
</tr>

<?php
} 
?>
</tbody>
</table>
<?php
include 'parts/footer.php';
?>