<?php  
include 'parts/header.php';
?>
<h3>Orders</h3>

<table class="table1">
<thead>
<tr>
<th>ID</th><th>Address</th><th>Quantity</th><th>Sub Total</th><th>Status</th>
</tr>
</thead>
<tbody>

<?php
$result = mysqli_query($conn, "SELECT * FROM orders join products on products.id=orders.products_id where users_id = '" . $_SESSION['user_id'] . "'") or die(mysql_error());  
while($product=mysqli_fetch_object($result)){
?>

<tr>
<td><?php echo $product->name;?></td>
<td><?php echo $product->shippingAddress;?></td>
<td><?php echo $product->quantity;?></td>
<td><?php echo $product->subTotal;?><span> $</span></td>
<td><?php echo "1";?></td>


</tr>

<?php
} 
?>
</tbody>
</table>

<br>

<?php
include 'parts/footer.php'
?>