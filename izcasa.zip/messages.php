<?php  
include 'parts/header.php';
?>

contact form

<?php  
include 'parts/footer.php';
?>