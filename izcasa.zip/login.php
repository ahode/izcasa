<?php  
include 'parts/header.php';
if(isset($_SESSION['user_id'])) {
	header("Location: shop.php");
}
if (isset($_POST['login'])) {
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$result = mysqli_query($conn, "SELECT * FROM users WHERE name = '" . $name. "' and password = '" . $password. "'");
	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['user_id'] = $row['id'];
		$_SESSION['user_name'] = $row['name'];	
		header("Location: shop.php");
	} else {
		$error_message = "Incorrect Email or Password!!!";
	}
}
?>

<form method="post" action="">
<h3>Login</h3>
Username:<br><input type="text" name="name" required size="30"><br>
Password:<br><input type="password" name="password" required size="30"><br><br>
<!--Please enter the captcha code:<br>
<img src="captcha.php" height="30" width="60" alt="CAPTCHA code" style="padding-top:7px;padding-bottom:3px;"><br>
<input type="text" class="txt" autocomplete="off" name="captcha" size="20"><br><br>-->
<input type="submit" class="buttn" value="Login" name="login"></form><br>
<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
<a href="register.php">Register a new account</a><br><br>
<br>
<?php
include 'parts/footer.php'
?>